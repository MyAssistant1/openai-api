# openai-api
This is a personal helping assistant. It is working with voice. You can send mail and add events to your calendar. And it is using also chatgpt api.
